docker build -t hrnet_demo_inference .
